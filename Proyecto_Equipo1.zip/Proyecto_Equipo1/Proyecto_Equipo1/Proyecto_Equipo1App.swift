//
//  Proyecto_Equipo1App.swift
//  Proyecto_Equipo1
//
//  Created by Alumno on 11/09/23.
//

import SwiftUI

@main
struct Proyecto_Equipo1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
